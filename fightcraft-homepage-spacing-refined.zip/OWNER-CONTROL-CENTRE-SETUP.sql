-- Fightcraft owner-only website content manager
-- Run once in Supabase Dashboard > SQL Editor > New query.
-- This does NOT change the existing photos table, storage bucket, or photo policies.

create table if not exists public.site_settings (
  id text primary key default 'main' check (id = 'main'),
  content jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.site_settings enable row level security;

grant select on public.site_settings to anon, authenticated;
grant insert, update on public.site_settings to authenticated;

drop policy if exists "Public can read Fightcraft site settings" on public.site_settings;
create policy "Public can read Fightcraft site settings"
on public.site_settings for select to anon, authenticated using (true);

drop policy if exists "Fightcraft owner can create site settings" on public.site_settings;
create policy "Fightcraft owner can create site settings"
on public.site_settings for insert to authenticated
with check (auth.uid() = 'e2f55ea6-1be2-4ce9-bcea-f91c1ff3ea53'::uuid);

drop policy if exists "Fightcraft owner can update site settings" on public.site_settings;
create policy "Fightcraft owner can update site settings"
on public.site_settings for update to authenticated
using (auth.uid() = 'e2f55ea6-1be2-4ce9-bcea-f91c1ff3ea53'::uuid)
with check (auth.uid() = 'e2f55ea6-1be2-4ce9-bcea-f91c1ff3ea53'::uuid);

insert into public.site_settings (id, content)
values ('main', jsonb_build_object(
  'heroEyebrow', 'Fightcraft BJJ · Mansfield Woodhouse, Nottinghamshire',
  'heroTitle', E'Brazilian Jiu-Jitsu.\nRight here in Mansfield.',
  'heroCopy', 'Learn the art of Brazilian Jiu-Jitsu in a team built around skill, discipline and getting better together. Whether it’s your first class or your next chapter on the mats, there’s a place for you.',
  'heroNote', 'Adults and kids · Beginners welcome · Mansfield Woodhouse',
  'aboutTitle', 'Make the mats your second home.',
  'aboutText', 'Fightcraft BJJ is a Brazilian Jiu-Jitsu academy in Mansfield Woodhouse. Training is about more than learning techniques: it’s about building confidence, staying curious and helping each other improve.',
  'trainingIntro', 'Whether you’re looking to learn a new skill, get fitter or develop your martial arts, find out which sessions are right for you.',
  'contactTitle', 'Ready to step onto the mats?',
  'contactText', 'Reach out to Fightcraft BJJ to ask about classes, beginner sessions, age groups and the current timetable.',
  'address', 'Unit 8 & 9, Block 2, 3 Old Mill Lane, Mansfield Woodhouse, Mansfield, NG19 9GB',
  'phone', '', 'email', '', 'prices', 'Please contact the academy for current membership prices and trial options.',
  'announcement', '', 'announcementEnabled', false,
  'accent', '#c6f36b', 'background', '#101312', 'panel', '#171c19',
  'openingHours', jsonb_build_array(
    jsonb_build_object('day','Monday','hours','Please contact us'),
    jsonb_build_object('day','Tuesday','hours','Please contact us'),
    jsonb_build_object('day','Wednesday','hours','Please contact us'),
    jsonb_build_object('day','Thursday','hours','Please contact us'),
    jsonb_build_object('day','Friday','hours','Please contact us'),
    jsonb_build_object('day','Saturday','hours','Please contact us'),
    jsonb_build_object('day','Sunday','hours','Please contact us')
  ),
  'timetable', jsonb_build_array(),
  'updatedAt', now()
))
on conflict (id) do nothing;
