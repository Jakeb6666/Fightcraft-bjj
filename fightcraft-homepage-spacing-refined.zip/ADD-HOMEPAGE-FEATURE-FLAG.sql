-- Run once in Supabase Dashboard > SQL Editor.
-- Adds a homepage feature switch without changing existing photos or security policies.
alter table public.photos
add column if not exists is_featured boolean not null default false;
